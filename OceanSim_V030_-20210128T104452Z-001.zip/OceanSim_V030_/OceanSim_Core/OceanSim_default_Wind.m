function [tws,twd] = wind_1(time,truth)

tws = 6.0;      % [m/s]
twd = d2r(90);   % [deg] From-direction
