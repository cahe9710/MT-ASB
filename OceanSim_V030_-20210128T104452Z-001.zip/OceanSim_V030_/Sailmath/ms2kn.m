function kn = ms2kn(ms);

kn = ms*3600/1852;