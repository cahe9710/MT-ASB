function ms = kn2ms(kn);

ms = kn/3600*1852;