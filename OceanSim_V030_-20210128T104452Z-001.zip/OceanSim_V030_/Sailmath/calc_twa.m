function twa = calc_twa(twd,yaw)

twa = unwrap_pi(twd-yaw);

ffff



