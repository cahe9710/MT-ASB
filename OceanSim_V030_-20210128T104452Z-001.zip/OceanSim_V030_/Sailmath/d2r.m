function r = d2r(angle)

r = deg2rad(angle);