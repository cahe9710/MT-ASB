function d = r2d(angle)

d = rad2deg(angle);