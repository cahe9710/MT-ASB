function rhs=R_matrix(alpha);
rhs=[cos(alpha) -sin(alpha); sin(alpha) cos(alpha)];
